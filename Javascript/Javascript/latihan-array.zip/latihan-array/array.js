let nilai = [75, 88, 92];

console.log("1. Nilai awal: ");
nilai.forEach((n, i ) => {
    console.log(`siswa ${i + 1} : ${n}`);

});
console.log("");

nilai.push(60);
console.log("2. setelah nilai 60 ditambah (push):");
console.log(nilai);
console.log("");

let nilaiTerakhir = nilai.pop();
console.log("3. setelah menghapus nilai terakhir (pop):", nilaiTerakhir);
console.log("Nilai sekarng:", nilai);
console.log("");

let nilaiBonus = nilai.map((n) => n + 5);
console.log("4. Nilai setelah ditambahkan bonus 5 poin (map):");
console.log(nilaiBonus);
console.log("");

console.log("5. cetak nilai akhir siswa:");
nilaiBonus.forEach((n, i) => {
    console.log(`siswa ${n, i}: ${n}`);
});