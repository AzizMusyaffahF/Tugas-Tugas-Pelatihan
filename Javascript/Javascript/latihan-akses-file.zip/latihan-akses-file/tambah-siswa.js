const fs = require ("fs");

const filePath = "siswa.json";
let daftar = [];

if (fs.existsSync(filePath)){
    const content = fs.readFileSync(filePath, "utf8");
    daftar = JSON.parse(content);
}

let siswaBaru1 = {
     nama:"SunFlower",
     kelas: "Web",
     nilai: [93, 97, 83],
};

let siswaBaru2 = {
     nama: "Magnolia",
     kelas: "Web",
     nilai: [98, 77, 68],
};

daftar.push(siswaBaru1);
daftar.push(siswaBaru2);

fs.writeFileSync(filePath, JSON.stringify(daftar, null, 2));
console.log("Data siswa berhasil ditambahkan ke siswa.json ");