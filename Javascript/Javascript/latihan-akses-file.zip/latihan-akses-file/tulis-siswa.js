const fs = require("fs");

let siswa = [
    {
    nama: "Lily",
    kelas: "Web",
    nilai: [78, 92, 87],
},
];

fs.writeFileSync("siswa.json", JSON.stringify(siswa, null, 2));
console.log("data siswa berhasil ditulis ke file siswa.json");